"""Patch SDL's android-project app/build.gradle: drop ndkBuild, use our CMake file."""
import re, sys
p = sys.argv[1]
s = open(p).read()

def strip_blocks(s, name):
    while True:
        m = re.search(r'\b' + name + r'\s*\{', s)
        if not m:
            return s
        i, depth = m.end(), 1
        while depth:
            depth += {'{': 1, '}': -1}.get(s[i], 0)
            i += 1
        s = s[:m.start()] + s[i:]

s = strip_blocks(s, 'externalNativeBuild')
s = re.sub(r'minSdk(Version)?\s+\d+', 'minSdkVersion 24', s)
s = re.sub(r'(defaultConfig\s*\{)',
           r"\1\n        ndk { abiFilters 'arm64-v8a' }\n"
           r"        externalNativeBuild { cmake { arguments '-DANDROID_STL=c++_shared' } }", s, 1)
s = re.sub(r'(\nandroid\s*\{)',
           r"\1\n    externalNativeBuild { cmake { path 'jni/CMakeLists.txt' } }", s, 1)
open(p, 'w').write(s)
print(s)
