#!/usr/bin/env bash
# Run on YOUR machine (needs network + git). Usage:
#   ./setup.sh /path/to/Kart-Public-master
# Creates ./srb2kart-android/ ready to open in Android Studio.
set -euo pipefail
KP_SRC="${1:?usage: setup.sh /path/to/Kart-Public-master}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$PWD/srb2kart-android"

SDL_TAG=release-2.28.5      # SDL2 tags: verify they exist if clone fails
MIX_TAG=release-2.6.3

mkdir -p "$OUT/.deps" && cd "$OUT/.deps"
[ -d SDL ]        || git clone --depth 1 --branch "$SDL_TAG" https://github.com/libsdl-org/SDL.git SDL
[ -d SDL2_mixer ] || git clone --depth 1 --branch "$MIX_TAG" --recursive https://github.com/libsdl-org/SDL_mixer.git SDL2_mixer

cd "$OUT"
# Gradle project template that ships inside SDL
cp -r .deps/SDL/android-project/. .
mkdir -p app/jni
cp -r .deps/SDL        app/jni/SDL
cp -r .deps/SDL2_mixer app/jni/SDL2_mixer
cp -r "$KP_SRC"        app/jni/Kart-Public
cp "$HERE/app-files/CMakeLists.txt"    app/jni/CMakeLists.txt
cp "$HERE/app-files/srb2_sources.cmake" app/jni/srb2_sources.cmake

# Apply the Android data-path patch to the game source
( cd app/jni/Kart-Public && patch -p1 < "$HERE/patches/0001-android-data-path.patch" )

# SDL's SDLActivity must see the SDL Java sources (template already symlinks/expects them;
# if app/src/main/java/org/libsdl is missing, copy from .deps/SDL/android-project/app/src/main/java)
echo
echo "Done. Next steps (see README.md):"
echo "  1. Edit app/build.gradle: use externalNativeBuild { cmake { path 'jni/CMakeLists.txt' } },"
echo "     abiFilters 'arm64-v8a', and minSdk 24."
echo "  2. Open $OUT in Android Studio and build."
