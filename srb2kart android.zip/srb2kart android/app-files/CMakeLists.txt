# SRB2Kart for Android: top-level CMake, lives in <android-project>/app/jni/
# Layout expected (setup.sh creates it):
#   app/jni/CMakeLists.txt        <- this file
#   app/jni/srb2_sources.cmake    <- generated source lists
#   app/jni/SDL                   <- SDL2 source (release-2.28.x)
#   app/jni/SDL2_mixer            <- SDL2_mixer source (release-2.6.x, --recursive)
#   app/jni/Kart-Public           <- the game source (patched)
cmake_minimum_required(VERSION 3.18)
project(SRB2Kart C CXX)
set(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -Wl,-z,max-page-size=16384")  # 16 KB page devices

set(KP ${CMAKE_CURRENT_SOURCE_DIR}/Kart-Public)

# ---------- SDL2 + SDL2_mixer (built from source, shared) ----------
set(SDL_STATIC OFF CACHE BOOL "" FORCE)
set(SDL_TEST   OFF CACHE BOOL "" FORCE)
add_subdirectory(SDL)

set(SDL2MIXER_VENDORED ON CACHE BOOL "" FORCE)
set(SDL2MIXER_SAMPLES  OFF CACHE BOOL "" FORCE)
set(SDL2MIXER_INSTALL  OFF CACHE BOOL "" FORCE)
set(SDL2MIXER_MIDI     OFF CACHE BOOL "" FORCE)   # no MIDI in Kart
set(SDL2MIXER_FLAC     OFF CACHE BOOL "" FORCE)
set(SDL2MIXER_OPUS     OFF CACHE BOOL "" FORCE)
set(SDL2MIXER_WAVPACK  OFF CACHE BOOL "" FORCE)
# Needed by Kart's music: Ogg Vorbis + tracker modules (mod/it/xm/s3m).
# Option names differ between SDL2_mixer releases: verify against the
# CMakeLists.txt of the version you cloned.
set(SDL2MIXER_VORBIS   STB  CACHE STRING "" FORCE)
set(SDL2MIXER_MOD      ON   CACHE BOOL "" FORCE)
add_subdirectory(SDL2_mixer)

# ---------- zlib: NDK ships it (-lz) ----------
find_library(Z_LIB z)

# ---------- libpng 1.2.46 (bundled) ----------
file(GLOB PNG_SRC ${KP}/libs/libpng-src/png*.c)
list(FILTER PNG_SRC EXCLUDE REGEX "pnggccrd|pngvcrd|pngtest")
add_library(kart_png STATIC ${PNG_SRC})
target_include_directories(kart_png PUBLIC ${KP}/libs/libpng-src)
target_link_libraries(kart_png PUBLIC ${Z_LIB})
target_compile_options(kart_png PRIVATE -w)

# ---------- libgme (bundled) ----------
file(GLOB GME_SRC ${KP}/libs/gme/gme/*.cpp)
add_library(kart_gme STATIC ${GME_SRC})
target_include_directories(kart_gme PUBLIC ${KP}/libs/gme)   # for #include "gme/gme.h"
target_compile_options(kart_gme PRIVATE -w)

# ---------- the game ----------
include(srb2_sources.cmake)
set(ALL_SRC
  ${SRB2_CORE_SOURCES} ${SRB2_RENDER_SOURCES} ${SRB2_GAME_SOURCES}
  ${SRB2_LUA_SOURCES}  ${SRB2_BLUA_SOURCES}   ${SRB2_SDL_SOURCES})
list(TRANSFORM ALL_SRC PREPEND ${KP}/src/)

# SDLActivity loads "libmain.so", so the game library MUST be named "main".
add_library(main SHARED ${ALL_SRC})

target_include_directories(main PRIVATE
  ${KP}/src ${KP}/src/sdl ${KP}/src/blua
  ${KP}/libs/libpng-src)

target_compile_definitions(main PRIVATE
  HAVE_SDL HAVE_MIXER SDLMAIN
  UNIXCOMMON
  HAVE_BLUA HAVE_ZLIB HAVE_PNG HAVE_LIBGME _LARGEFILE64_SOURCE
  NONX86 NORUSEASM          # no x86 asm on ARM
  NOMUMBLE                  # shm_open is not in bionic
  # Deliberately NOT defined: HWRENDER (desktop GL; software renderer first),
  # HAVE_CURL, HAVE_MINIUPNPC, USE_STUN, HAVE_DISCORDRPC, CMAKECONFIG
)

target_compile_options(main PRIVATE
  -fno-strict-aliasing -fwrapv -w
  # NDK clang (16+) turns these old-C idioms into hard errors; downgrade them.
  $<$<COMPILE_LANGUAGE:C>:-Wno-error=implicit-function-declaration>
  $<$<COMPILE_LANGUAGE:C>:-Wno-error=implicit-int>
  $<$<COMPILE_LANGUAGE:C>:-Wno-error=int-conversion>
  $<$<COMPILE_LANGUAGE:C>:-Wno-error=incompatible-pointer-types>)   # old C code; silence noise, keep fixed-point math defined

target_link_libraries(main PRIVATE
  SDL2 SDL2_mixer kart_png kart_gme ${Z_LIB} m log android)
